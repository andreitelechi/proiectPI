<?php

$conn = mysqli_connect('localhost' , 'root' , '', 'ewd' ) or die ('connection failed');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href= "css/css.scss">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"/>

</head>
<body>
    <!-- antet !--> 


    <header class="header">

        <a href = "home.php" class = "logo"><i class = "fas fa-store"></i> Shop</a>

        <form action="" class = "search-form">
            <input type = "search" id = "search-box" placeholder = "cauta">
            <label for = "search-box" class = "fas fa-search"></label>
        </form>

        <div class = "icons">
            <div id = "menu-btn" class = "fas fa-bars"></div>
            <div id = "search-btn" class = "fas fa-search"></div>
            <a href = "login.php" class = "fas fa-user"></a>
        </div>

    </header>





    <!-- sfarsit antet --> 


    
    
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>

    <script src = "js/js.js"></script>

</body>
</html>