<?php

$conn = mysqli_connect('localhost' , 'root' , '', 'ewd' ) or die ('connection failed');

?>