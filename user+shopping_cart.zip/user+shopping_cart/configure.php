<?php

$conn = mysqli_connect('localhost' , 'root' , '', 'ewd' ) or die ('connection failed');
//$sql = mysql_select_db ('user_info',$conn);

?>