<?php

include 'configure.php';

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href = "css/checkout.css">
    <title>Checkout</title>

</head>
<body>
<div class="container">

<form action="">

    <div class="row">

        <div class="col">

            <h3 class="title">Datele cumparatorului</h3>

            <div class="inputBox">
                <span>Nume complet :</span>
                <input type="text" placeholder="Ion Popescu">
            </div>
            <div class="inputBox">
                <span>Email :</span>
                <input type="email" placeholder="example@example.com">
            </div>
            <div class="inputBox">
                <span>Adresa :</span>
                <input type="text" placeholder="room - street - locality">
            </div>
            <div class="inputBox">
                <span>Oras :</span>
                <input type="text" placeholder="Cluj-Napoca">
            </div>

            <div class="flex">
                <div class="inputBox">
                    <span>Judet :</span>
                    <input type="text" placeholder="Romania">
                </div>
                <div class="inputBox">
                    <span>Cod postal :</span>
                    <input type="text" placeholder="123 456">
                </div>
            </div>

        </div>

        <div class="col">

            <h3 class="title">Plata</h3>

            <div class="inputBox">
                <span>Carduri acceptate :</span>
                <img src="card_img.png" alt="">
            </div>
            <div class="inputBox">
                <span>Numele de pe card :</span>
                <input type="text" placeholder="Ion Popescu">
            </div>
            <div class="inputBox">
                <span>Numarul de pe card :</span>
                <input type="number" placeholder="1111-2222-3333-4444">
            </div>
            <div class="inputBox">
                <span>Luna expirarii :</span>
                <input type="text" placeholder="Ianuarie">
            </div>

            <div class="flex">
                <div class="inputBox">
                    <span>Anul expirarii :</span>
                    <input type="number" placeholder="2025">
                </div>
                <div class="inputBox">
                    <span>CVV :</span>
                    <input type="text" placeholder="123">
                </div>
            </div>

        </div>

    </div>

    <input type="submit" value="Platiti" class="submit-btn">

</form>

</div>    
</body>
</html>