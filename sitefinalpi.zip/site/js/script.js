/*document.querySelector('#search-box').addEventListener('input', filterList);

function filterList(){
    const searchInput = document.querySelector('#search-box');
    const filter  = searchInput.value.toLowerCase();
    const listItems = document.querySelectorAll('.box');


    listItems.forEach((item) =>{
        let text = item.textContent;
        if(text.toLowerCase().includes(filter.toLowerCase())){
            item.style.display = '';
        }else{
            item.style.display = 'none';
        }
    });
}

*/

  
/*document.querySelector('#search-box').addEventListener('input', filterList);

function filterList() {
    const searchInput = document.querySelector('#search-box');
    const filter = searchInput.value.toLowerCase();
    const deleteItems = document.querySelectorAll('.nume_produs');

    deleteItems.forEach((item) => {
        let text = item.textContent.toLowerCase();
        const boxElement = item.closest('.box');
        
        if (text.includes(filter)) {
            boxElement.style.display = '';
        } else {
            boxElement.style.display = 'none';
            boxElement.remove(); // Remove the box element from the DOM
        }
    });
}*/

/*document.querySelector('#search-box').addEventListener('input', filterList);

// Store the original display state of each .box element
const originalDisplayStates = new Map();

// Get the original display state of a box element
function getOriginalDisplayState(boxElement) {
    if (originalDisplayStates.has(boxElement)) {
        return originalDisplayStates.get(boxElement);
    }
    const display = window.getComputedStyle(boxElement).display;
    originalDisplayStates.set(boxElement, display);
    return display;
}

function filterList() {
    const searchInput = document.querySelector('#search-box');
    const filter = searchInput.value.toLowerCase();
    const deleteItems = document.querySelectorAll('.nume_produs');

    deleteItems.forEach((item) => {
        let text = item.textContent.toLowerCase();
        const boxElement = item.closest('.box');

        if (text.includes(filter)) {
            boxElement.style.display = getOriginalDisplayState(boxElement);
        } else {
            boxElement.style.display = 'none';
        }
    });

    if (filter === '') {
        const allBoxes = document.querySelectorAll('.box');
        allBoxes.forEach((box) => {
            box.style.display = getOriginalDisplayState(box);
        });
    }
}
*/
document.addEventListener('DOMContentLoaded', setupFilterList);

function setupFilterList() {
  const searchInput = document.querySelector('#search-box');
  const allBoxes = document.querySelectorAll('.box');
  const originalDisplayStates = new Map();

  // Capture and store the original display state for all .box elements
  allBoxes.forEach((boxElement) => {
    originalDisplayStates.set(boxElement, window.getComputedStyle(boxElement).display);
  });

  searchInput.addEventListener('input', filterList);

  function filterList() {
    const filter = searchInput.value.toLowerCase();
    const deleteItems = document.querySelectorAll('.nume_produs');

    deleteItems.forEach((item) => {
      let text = item.textContent.toLowerCase();
      const boxElement = item.closest('.box');

      if (text.includes(filter)) {
        boxElement.style.display = getOriginalDisplayState(boxElement);
      } else {
        boxElement.style.display = 'none';
      }
    });

    if (filter === '') {
      allBoxes.forEach((box) => {
        box.style.display = getOriginalDisplayState(box);
      });
    }
  }

  // Get the original display state of a box element
  function getOriginalDisplayState(boxElement) {
    if (originalDisplayStates.has(boxElement)) {
      return originalDisplayStates.get(boxElement);
    }
    return '';
  }
}


