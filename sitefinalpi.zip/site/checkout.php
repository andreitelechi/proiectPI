<?php

include 'configure.php';

// Import PHPMailer classes into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Required files
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';


   // $name = mysqli_real_escape_string($conn, $_POST['name']);
    //$email = mysqli_real_escape_string($conn, $_POST['email']);

try {
    $mail = new PHPMailer(true);

    // Server settings
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'andreitelechi2003@gmail.com';
    $mail->Password   = 'usqiciqqysqrdvru';
    $mail->SMTPSecure = 'ssl';
    $mail->Port       = 465;

    // Recipients
    $mail->setFrom('andreitelechi2003@gmail.com', 'Andrei Telechi');
    $mail->addAddress('andreitelechi2003@gmail.com', 'Andrei Telechi');

    // Content
    $mail->isHTML(true);
    $mail->Subject = "Confirmare email pentru comanda dvs.";
    $mail->Body    = "Salut! Îţi mulţumim pentru că ai ales să cumperi de la noi, produsele tale vor ajunge la tine în cel mai scurt timp. Vă urăm o zi minunată!";

    // Send email
    $mail->send();

    $message[] = 'Comandă plasată cu succes!';
} catch (Exception $e) {
    $message[] = 'Eroare la trimiterea emailului: ' . $mail->ErrorInfo;
}



?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href = "css/checkout.css">
    <title>Checkout</title>

</head>
<body>
<div class="container">

<form action="">

    <div class="row">

        <div class="col">

            <h3 class="title">Datele cumparatorului</h3>

            <div class="inputBox">
                <span>Nume complet :</span>
                <input type="text" placeholder="Ion Popescu">
            </div>
            <div class="inputBox">
                <span>Email :</span>
                <input type="email" placeholder="example@example.com">
            </div>
            <div class="inputBox">
                <span>Adresa :</span>
                <input type="text" placeholder="room - street - locality">
            </div>
            <div class="inputBox">
                <span>Oras :</span>
                <input type="text" placeholder="Cluj-Napoca">
            </div>

            <div class="flex">
                <div class="inputBox">
                    <span>Judet :</span>
                    <input type="text" placeholder="Romania">
                </div>
                <div class="inputBox">
                    <span>Cod postal :</span>
                    <input type="text" placeholder="123 456">
                </div>
            </div>

        </div>

        <div class="col">

            <h3 class="title">Plata</h3>

            <div class="inputBox">
                <span>Carduri acceptate :</span>
                <img src="card_img.png" alt="">
            </div>
            <div class="inputBox">
                <span>Numele de pe card :</span>
                <input type="text" placeholder="Ion Popescu">
            </div>
            <div class="inputBox">
                <span>Numarul de pe card :</span>
                <input type="number" placeholder="1111-2222-3333-4444">
            </div>
            <div class="inputBox">
                <span>Luna expirarii :</span>
                <input type="text" placeholder="Ianuarie">
            </div>

            <div class="flex">
                <div class="inputBox">
                    <span>Anul expirarii :</span>
                    <input type="number" placeholder="2025">
                </div>
                <div class="inputBox">
                    <span>CVV :</span>
                    <input type="text" placeholder="123">
                </div>
            </div>

        </div>

    </div>

    <input type="submit" name="submit" value="Platiti" class="submit-btn">

</form>

</div>    
</body>
</html>