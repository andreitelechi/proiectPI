<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>about</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- swiper css link  -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- cusom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    
<!-- header section starts  -->

<header class="header">

    <section class="flex">

        <a href="home.php" class="logo"> <i class="fas fa-store"></i> Elektroniks </a>

        <!--<form action="" class="search-form">
            <input type="search" id="search-box" placeholder="search here...">
            <label for="search-box" class="fas fa-search"></label>
        </form>
-->

        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <a href="login.php" class="fas fa-user"></a>
            
            
        </div>

    </section>

</header>

<!-- header section ends -->

<!-- side-bar section starts -->

<div class="side-bar">

    <div id="close-side-bar" class="fas fa-times"></div>

    <div class="user">
        <img src="images/pagina-mare.jpg" alt="">
        <h3>Telechi Andrei</h3>
        <a href="#">admin</a>
    </div>

    <nav class="navbar">
        <a href="home.php"> <i class="fas fa-angle-right"></i> home </a>
        <a href="about.php"> <i class="fas fa-angle-right"></i> about </a>
        <a href="contact.php"> <i class="fas fa-angle-right"></i> contact </a>
        <a href="login.php"> <i class="fas fa-angle-right"></i> login </a>
        <a href="register.php"> <i class="fas fa-angle-right"></i> register </a>
        
    </nav>

</div>

<!-- side-bar section ends -->

<!-- about section starts  -->

<section class="about">

    

    <div class="content">
        <h3>Povestea noastră (pe scurt)</h3>
        <p>Echipa noastră de dezvoltare web este o echipă talentată și pasionată, unită pentru a crea o experiență online extraordinară. De la designeri grafici la programatori, ne-am dedicat timp și energie pentru a construi un site intuitiv și atractiv. Suntem aici pentru a vă oferi cea mai bună experiență online posibilă. Astăzi, suntem mândri de munca noastră și de site-ul pe care l-am creat împreună. Dar povestea noastră nu se oprește aici. Continuăm să inovăm și să creăm, să ne adaptăm și să evoluăm, pentru că suntem conduși de dorința de a oferi o experiență online extraordinară și de a aduce un zâmbet pe fețele clienților noștri. Povestea echipei noastre de dezvoltare web este o poveste de pasiune, creativitate și angajament. Suntem bucuroși să împărtășim această călătorie cu voi, dragi utilizatori ai site-ului nostru, și suntem aici pentru a vă servi în fiecare pas al drumului.</p>
        <p>Cu drag, Echipa noastră de dezvoltare web.</p>
        
    </div>

</section>

<!-- about section ends -->

<!-- faq section starts  -->

<section class="faq">

    <h1 class="heading"> Întrebări și <span>răspunsuri</span> </h1>

    <div class="accordion-container">

        <div class="accordion">
            <div class="accordion-heading">
                <h3>Cum putem să facem o comandă?</h3>
                <i class="fas fa-angle-down"></i>
            </div>
            <p class="accordioin-content">
                În primul rând, pentru a face o comandă trebuie sa ai un cont la noi. Dacă ai deja, te loghezi, adaugi produsele preferate în coș, plătești, iar apoi te poți bucura de ceea ce ai comandat în cel mai scurt timp.
            </p>
        </div>

        <div class="accordion">
            <div class="accordion-heading">
                <h3>Cum creez un cont?</h3>
                <i class="fas fa-angle-down"></i>
            </div>
            <p class="accordioin-content">
                Dacă nu ai un cont la noi, nu e nicio problemă, trebuie doar să dai câteva click-uri. Apeși pe register, completezi formularul pentru înregistrare și apoi cât ai zice pește vei avea un cont și vei putea relua cumpărăturile.
            </p>
        </div>

        <div class="accordion">
            <div class="accordion-heading">
                <h3>Cum pot plăti online?</h3>
                <i class="fas fa-angle-down"></i>
            </div>
            <p class="accordioin-content">
                Pentru cei care nu vor să se mai complice să numere banii bancnotă cu bancnotă, la noi poți plăti și online cu cardul bancar, doar treci datele cardului, confirmi plata și curierul va fi la ușa ta în cel mai scurt timp ca să îți înmâneze produsul pe care l-ai plătit.
            </p>
        </div>

        <div class="accordion">
            <div class="accordion-heading">
                <h3>Este plata online sigură?</h3>
                <i class="fas fa-angle-down"></i>
            </div>
            <p class="accordioin-content">
            Înțelegem că siguranța plăților online este o preocupare importantă pentru tine și vrem să îți oferim asigurări complete cu privire la acest aspect. Plata cu cardul pe site-ul nostru este un proces sigur și protejat, iar securitatea ta este o prioritate absolută pentru noi.
            </p>
        </div>

        <div class="accordion">
            <div class="accordion-heading">
                <h3>Cum vă pot contacta dacă am o problemă?</h3>
                <i class="fas fa-angle-down"></i>
            </div>
            <p class="accordioin-content">
                Ne poți contacta foarte simplu, la doar o apăsare de buton. Pentru mai multe detalii apasă pe butonul "contact".
            </p>
        </div>

    </div>

</section>

<!-- faq section ends -->

<!-- review section starts  -->

<section class="review">

    <h1 class="heading"> Review-urile <span>clienților</span> </h1>

    <div class="swiper review-slider">

        <div class="swiper-wrapper">

            <div class="swiper-slide slide">
                <img src="images/pic-1.png" alt="">
                <h3>Mihai Popa</h3>
                <span>Inginer</span>
                <p>Am fost extrem de impresionat de calitatea produsului pe care l-am achiziționat de la voi. Nu doar că a depășit așteptările mele, dar și serviciul clienți a fost excelent. Recomand cu căldură!</p>
            </div>

            <div class="swiper-slide slide">
                <img src="images/pic-2.png" alt="">
                <h3>Maria Ionescu</h3>
                <span>Designer</span>
                <p>Experiența mea de cumpărături pe site-ul vostru a fost minunată. Interfața intuitivă și ușurința de a găsi produsele dorite m-au impresionat. Livrarea a fost rapidă și ambalajul a fost de calitate. Vă mulțumesc!</p>
            </div>

            <div class="swiper-slide slide">
                <img src="images/pic-3.png" alt="">
                <h3>Bogdan Bravu</h3>
                <span>Ghid Turistic</span>
                <p>Vreau să vă mulțumesc pentru răspunsurile rapide și ajutorul oferit în procesul meu de comandă. Am avut unele întrebări și îngrijorări, iar echipa voastră a fost mereu promptă și amabilă. Produsul achiziționat a fost exact ceea ce speram. Mulțumesc!</p>
            </div>

            <div class="swiper-slide slide">
                <img src="images/pic-4.png" alt="">
                <h3>Cristina Constantinescu</h3>
                <span>Hair Stylist</span>
                <p>Am apreciat cu adevărat atenția acordată de echipa voastră. M-au contactat pentru a se asigura că am primit produsul în stare perfectă și că sunt mulțumită de achiziție. Serviciul clienți excelent face diferența!</p>
            </div>

            <div class="swiper-slide slide">
                <img src="images/pic-5.png" alt="">
                <h3>Alex Ionas</h3>
                <span>Profesor</span>
                <p>Am cumpărat mai multe produse de la voi și sunt extrem de mulțumit. Calitatea este impecabilă, iar prețurile sunt competitive. În plus, livrarea a fost rapidă și ambalajul a protejat perfect produsele. Sunt un client fericit și voi continua să cumpăr de la voi!</p>
            </div>

            <div class="swiper-slide slide">
                <img src="images/pic-6.png" alt="">
                <h3>Asuka Shinobi</h3>
                <span>Economist</span>
                <p>De când m-am mutat în România, orice comandă o efectuez la voi. Am apreciat faptul că oferiți asistență nu doar în limba română, ceea ce mi-a fost de ajutor până am reușit să învăț limba, sunt foarte mulțumită, am să vă recomand și prietenilor.</p>
            </div>

        </div>

    </div>

</section>

<!-- review section ends -->













<!-- footer section starts  -->

<footer class="footer">

    <section class="quick-links">

        <a href="home.php" class="logo"> <i class="fas fa-store"></i> Elektroniks </a>
    
        <div class="links">
            <a href="home.php"> home </a>
            <a href="about.php"> about </a>
            <a href="contact.php"> contact </a>
            <a href="login.php"> login </a>
            <a href="register.php"> register </a>
            
        </div>
    
        <div class="share">
            <a href="https://www.facebook.com/andrei.telechi.5/" class="fab fa-facebook"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="https://www.instagram.com/telechiandrei/" class="fab fa-instagram"></a>
            
        </div>
    
    </section>
    
   

</footer>

<!-- footer section ends -->




<!-- swiper js link      -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/js.js"></script>

</body>
</html>