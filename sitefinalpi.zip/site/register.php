<?php
//$conn = mysqli_connect('localhost','root','','ewd') or die ('connection failed');


include 'configure.php';



//ini_set("SMTP", "localhost");
//ini_set("smtp_port", "25");

// Import PHPMailer classes into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Required files
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

if(isset($_POST['submit'])){
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $cpassword = mysqli_real_escape_string($conn, $_POST['cpassword']);
    

    if ($password !== $cpassword) {
        $message[] = 'Parolele nu coincid!';
    } else {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $confirmation_token = bin2hex(random_bytes(32)); // Generate a random confirmation token

        $select = mysqli_query($conn, "SELECT * FROM `user_form` WHERE email = '$email'") or die('query failed');
        if(mysqli_num_rows($select) > 0 ){
            $message[] = 'Utilizatorul există deja!';
        }else{
            mysqli_query($conn, "INSERT INTO `user_form` (name, email, password, confirmation_token) VALUES ('$name', '$email', '$hashedPassword', '$confirmation_token')") or die('query failed');

            try {
                $mail = new PHPMailer(true);

                // Server settings
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'andreitelechi2003@gmail.com';
                $mail->Password   = 'usqiciqqysqrdvru';
                $mail->SMTPSecure = 'ssl';
                $mail->Port       = 465;

                // Recipients
                $mail->setFrom('andreitelechi2003@gmail.com', 'Andrei Telechi');
                $mail->addAddress($email, $name);

                // Content
                $mail->isHTML(true);
                $mail->Subject = "Confirmare email pentru autentificare";
                $mail->Body    = "Salut, $name! Emailul tau a fost confirmat cu succes. Te poti intoarce la pagina de login apăsând pe acest link http://localhost/site/login.php";

                // Send email
                $mail->send();

                $message[] = 'Înregistrarea a avut loc cu succes! Un email de confirmare a fost trimis la adresa dvs.';
            } catch (Exception $e) {
                $message[] = 'Eroare la trimiterea emailului: ' . $mail->ErrorInfo;
            }

            
        }
    }


    //$select = mysqli_query($conn, "SELECT * FROM 'user_form' WHERE email = '$email' AND password = '$password'") or die('query failed' . mysqli_error($conn));
    //if(mysqli_num_rows($select) > 0 ){
        //$message[] = 'utilizatorul exista deja!';
    //}else{
        //mysqli_query($conn, "INSERT INTO 'user_form'(name, email, password) VALUES('$name', '$email', '$password')") or die('query failed' . mysqli_error($conn));
        //$message[] = 'inregistrarea a avut loc cu succes!';
    //}
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>register</title>

    <!-- link fisier CSS -->

    <link rel="stylesheet" href="css/backstyle.css">
</head>
<body>


<?php
if(isset($message)){
    foreach($message as $message){
        echo '<div class="message" onclick="this.remove();">'.$message.'</div>';
    }
}
?>

    <div class="form-container">
        <form action="" method="post">
            <h3>Inregistrati-va acum</h3>
            <input type="text" name="name" required placeholder="Introduceti numele de utilizator" class="box">
            <input type="email" name="email" required placeholder="Introduceti email-ul" class="box">
            <input type="password" name="password" required placeholder="Introduceti parola" class="box">
            <input type="password" name="cpassword" required placeholder="Confirmati parola" class="box">
            <input type="submit" name="submit" class="btn" value="Inregistrati-va acum">
            <p>Ai deja un cont? <a href="login.php">login</a></p>

        </form>
    </div>
</body>
</html>