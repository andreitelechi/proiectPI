<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- swiper css link  -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- cusom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    
<!-- header section starts  -->

<header class="header">

    <section class="flex">

        <a href="home.php" class="logo"> <i class="fas fa-store"></i> Elektroniks </a>

        <form action="" class="search-form">
            <input type="text" id="search-box" placeholder="search here...">
            <label for="search-box" class="fas fa-search"></label>
        </form>

        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <a href="login.php" class="fas fa-user"></a>
            
           
        </div>

    </section>

</header>

<!-- header section ends -->

<!-- side-bar section starts -->

<div class="side-bar">

    <div id="close-side-bar" class="fas fa-times"></div>

    <div class="user">
        <img src="images/pagina-mare.jpg" alt="">
        <h3>Telechi Andrei</h3>
        <a href="#">admin</a>
    </div>

    <nav class="navbar">
        <a href="home.php"> <i class="fas fa-angle-right"></i> home </a>
        <a href="about.php"> <i class="fas fa-angle-right"></i> about </a>
        
        <a href="contact.php"> <i class="fas fa-angle-right"></i> contact </a>
        <a href="login.php"> <i class="fas fa-angle-right"></i> login </a>
        <a href="register.php"> <i class="fas fa-angle-right"></i> register </a>
        
    </nav>

</div>

<!-- side-bar section ends -->

<!-- home section starts  -->

<div class="home-container">

    <section class="home">

        <div class="swiper home-slider">
    
            <div class="swiper-wrapper">
    
            <div class="swiper-slide slide">
                <div class="image">
                    <img src="images/home-img-1.jpg" alt="">
                </div>
                <div class="content">
                    <span>Până la 50% reducere </span>
                    <h3>Smartphone-uri</h3>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
    
            <div class="swiper-slide slide">
                <div class="image">
                    <img src="images/home-img-2.jpg" alt="">
                </div>
                <div class="content">
                    <span>Până la 58% reducere</span>
                    <h3>Smartwatch-uri</h3>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
    
            <div class="swiper-slide slide">
                <div class="image">
                    <img src="images/home-img-3.jpg" alt="">
                </div>
                <div class="content">
                    <span>Până la 75% reducere</span>
                    <h3>Căști</h3>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
    
            </div>
    
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
    
        </div>
    
    </section>

</div>

<!-- home section ends -->

<!-- banner section starts  -->

<section class="banner">

    <div class="box-container">

        <a href="login.php" class="box">
            <img src="images/banner-1.jpg" alt="">
            <div class="content">
                <span>Ofertă specială</span>
                <h3>50% reducere</h3>
                
            </div>
            
        </a>

        <a href="login.php" class="box">
            <img src="images/banner-2.jpg" alt="">
            <div class="content">
                <span>Ofertă specială</span>
                <h3>50% reducere</h3>
            </div>
        </a>

        <a href="login.php" class="box">
            <img src="images/banner-3.jpg" alt="">
            <div class="content">
                <span>Ofertă specială</span>
                <h3>50% reducere</h3>
            </div>
        </a>
        
    </div>

</section>

<!-- banner section ends -->

<!-- arrivals section starts  -->

<section class="arrivals">

    <h1 class="heading"> Produse <span>noi</span> </h1>

    <div class="box-container">

        <div class="box" data-name="Televizor HD">
            <div class="image">
                <img src="images/arrival-1.jpg" class="main-img" alt="">
                <img src="images/arrival-1-hover.jpg" class="hover-img" alt="">
            </div>
            <div class="content">
                <div class = "nume_produs" ><h3>Televizor HD</h3></div>
                <div class="price"> 1000RON <span>1500RON</span> </div>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    
                    
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images/arrival-2.jpg" class="main-img" alt="">
                <img src="images/arrival-2-hover.jpg" class="hover-img" alt="">
            </div>
            <div class="content">
                <h3 class = "nume_produs">Laptop Lenovo Legion</h3>
                <div class="price"> 5000RON <span>6500RON</span> </div>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images/arrival-3.jpg" class="main-img" alt="">
                <img src="images/arrival-3-hover.jpg" class="hover-img" alt="">
            </div>
            <div class="content">
                <h3 class = "nume_produs">Iphone</h3>
                <div class="price"> 3000RON <span>4500RON</span> </div>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images/arrival-4.jpg" class="main-img" alt="">
                <img src="images/arrival-4-hover.jpg" class="hover-img" alt="">
            </div>
            <div class="content">
                <h3 class = "nume_produs">Imprimantă color</h3>
                <div class="price"> 1200RON <span>1700RON</span> </div>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images/arrival-5.jpg" class="main-img" alt="">
                <img src="images/arrival-5-hover.jpg" class="hover-img" alt="">
            </div>
            <div class="content">
                <h3 class = "nume_produs">Caști Wireless</h3>
                <div class="price"> 300RON <span>4500RON</span> </div>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images/arrival-6.jpg" class="main-img" alt="">
                <img src="images/arrival-6-hover.jpg" class="hover-img" alt="">
            </div>
            <div class="content">
                <h3 class = "nume_produs">Microfon</h3>
                <div class="price"> 350RON <span>500RON</span> </div>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images/product-1.jpg" class="main-img" alt="">
                <img src="images/product-1-hover.jpg" class="hover-img" alt="">
            </div>
            <div class="content">
                <h3 class = "nume_produs">Telefon</h3>
                <div class="price"> 1350RON <span>1500RON</span> </div>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/product-2.jpg" class="main-img" alt="">
                <img src="images/product-2-hover.jpg" class="hover-img" alt="">
            </div>
            <div class="content">
                <h3 class = "nume_produs">Cameră Nikon</h3>
                <div class="price"> 1700RON <span>1900RON</span> </div>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/product-3.jpg" class="main-img" alt="">
                <img src="images/product-3-hover.jpg" class="hover-img" alt="">
            </div>
            <div class="content">
                <h3 class = "nume_produs">Televizor 4K </h3>
                <div class="price"> 1900RON <span>2100RON</span> </div>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/product-4.jpg" class="main-img" alt="">
                <img src="images/product-4-hover.jpg" class="hover-img" alt="">
            </div>
            <div class="content">
                <h3 class = "nume_produs">Alexa Echo </h3>
                <div class="price"> 1200RON <span>1400RON</span> </div>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/product-5.jpg" class="main-img" alt="">
                <img src="images/product-5-hover.jpg" class="hover-img" alt="">
            </div>
            <div class="content">
                <h3 class = "nume_produs">Smart Weather </h3>
                <div class="price"> 200RON <span>400RON</span> </div>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/product-6.jpg" class="main-img" alt="">
                <img src="images/product-6-hover.jpg" class="hover-img" alt="">
            </div>
            <div class="content">
                <h3 class = "nume_produs">Smart Watch </h3>
                <div class="price"> 800RON <span>900RON</span> </div>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/product-7.jpg" class="main-img" alt="">
                <img src="images/product-7-hover.jpg" class="hover-img" alt="">
            </div>
            <div class="content">
                <h3 class = "nume_produs">Căști Wireless </h3>
                <div class="price"> 300RON <span>500RON</span> </div>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/product-8.jpg" class="main-img" alt="">
                <img src="images/product-8-hover.jpg" class="hover-img" alt="">
            </div>
            <div class="content">
                <h3 class = "nume_produs">Samsung S9 </h3>
                <div class="price"> 1800RON <span>2000RON</span> </div>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/product-9.jpg" class="main-img" alt="">
                <img src="images/product-9-hover.jpg" class="hover-img" alt="">
            </div>
            <div class="content">
                <h3 class = "nume_produs">Smart Camera </h3>
                <div class="price"> 500RON <span>800RON</span> </div>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <a href="login.php" class="btn">Cumpără</a>
                </div>
            </div>
        </div>

    </div>

</section>

<!-- arrivals section ends -->
















<!-- footer section starts  -->

<footer class="footer">

    <section class="quick-links">

        <a href="home.php" class="logo"> <i class="fas fa-store"></i> Elektroniks </a>
    
        <div class="links">
            <a href="home.php"> home </a>
            <a href="about.php"> about </a>
            <a href="contact.php"> contact </a>
            <a href="login.php"> login </a>
            <a href="register.php"> register </a>
           
        </div>
    
        <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
           
        </div>
    
    </section>
    
    

</footer>

<!-- footer section ends -->




<!-- swiper js link      -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/js.js"></script>
<script src="js/script.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</body>
</html>