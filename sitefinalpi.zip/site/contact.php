<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>contact</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- swiper css link  -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- cusom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    
<!-- header section starts  -->

<header class="header">

    <section class="flex">

        <a href="home.php" class="logo"> <i class="fas fa-store"></i> Elektroniks </a>

       <!-- <form action="" class="search-form">
            <input type="search" id="search-box" placeholder="search here...">
            <label for="search-box" class="fas fa-search"></label>
        </form>
-->

        <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <a href="login.php" class="fas fa-user"></a>
            
           
        </div>

    </section>

</header>

<!-- header section ends -->

<!-- side-bar section starts -->

<div class="side-bar">

    <div id="close-side-bar" class="fas fa-times"></div>

    <div class="user">
        <img src="images/pagina-mare.jpg" alt="">
        <h3>Telechi Andrei</h3>
        <a href="#">admin</a>
    </div>

    <nav class="navbar">
        <a href="home.php"> <i class="fas fa-angle-right"></i> home </a>
        <a href="about.php"> <i class="fas fa-angle-right"></i> about </a>
        <a href="contact.php"> <i class="fas fa-angle-right"></i> contact </a>
        <a href="login.php"> <i class="fas fa-angle-right"></i> login </a>
        <a href="register.php"> <i class="fas fa-angle-right"></i> register </a>
    </nav>

</div>

<!-- side-bar section ends -->

<!-- contact info section starts  -->

<section class="info-container">

    <div class="box-container">

        <div class="box">
            <i class="fas fa-map"></i>
            <h3>address</h3>
            <p>Timisoara, Romania - 300678</p>
        </div>

        <div class="box">
            <i class="fas fa-envelope"></i>
            <h3>email</h3>
            <p>andreitelechi2003@gmail.com</p>
            <p>telechi.andrei@yahoo.com</p>
        </div>

        <div class="box">
            <i class="fas fa-phone"></i>
            <h3>number</h3>
            <p>+40734208500</p>
            <p>+40729257690</p>
        </div>

    </div>

</section>

<!-- contact info section ends -->

<!-- contact section starts  -->

<section class="contact">

    <form action="">
        <h3>get in touch</h3>
        <p>Dragi clienți,
vă mulțumim că ați ales serviciile noastre și vrem să vă asigurăm că suntem întotdeauna aici pentru a vă ajuta. Dacă aveți întrebări, nelămuriri sau aveți nevoie de asistență suplimentară, vă rugăm să ne contactați folosind una dintre următoarele modalități.
Număr de telefon, sunați-ne la numărul nostru de telefon dedicat pentru asistență clienți. Echipa noastră prietenoasă vă va oferi răspunsuri la întrebările dvs. și vă va ajuta în orice fel posibil.
E-mail: Dacă preferați să ne contactați în scris, puteți trimite un e-mail la adresa noastră de asistență clienți. Vă rugăm să scrieți un mesaj detaliat, iar unul dintre reprezentanții noștri vă va răspunde cât mai curând posibil.
Rețelele sociale: Suntem prezenți și pe platformele de socializare. Puteți să ne urmăriți și să ne contactați prin intermediul paginii noastre de Facebook, Instagram sau Twitter. Vom răspunde cu promptitudine la mesajele și comentariile dvs.
Vă încurajăm să ne contactați oricând aveți nevoie de ajutor sau informații suplimentare. Suntem aici pentru a asigura că aveți o experiență excelentă cu serviciile noastre.
Cu respect,echipa noastră de asistență clienți.</p>
        <div class="inputBox">
            <input type="text" placeholder="your name">
            <input type="email" placeholder="your email">
        </div>
        <div class="inputBox">
            <input type="number" placeholder="your number">
            <input type="text" placeholder="subject">
        </div>
        <textarea name="" placeholder="your message" id="" cols="30" rows="10"></textarea>
        <input type="submit" value="send message" class="btn">
    </form>

    <iframe class="map"  src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d15744.81494264391!2d21.218544918611904!3d45.764849900265844!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sro!2sro!4v1685870098479!5m2!1sro!2sro" width="600" height="450" style="border:0;"  referrerpolicy="no-referrer-when-downgrade"></iframe></iframe>

</section>

<!-- contact section ends -->

<!-- newsletter section starts  -->

<div class="newsletter-container">

    <section class="newsletter">

        <div class="content">
            <h3>newsletter</h3>
            <p>subscribe for weekly newsletter.</p>
        </div>
    
        <form action="">
            <input type="email" name="" placeholder="enter your email" id="" class="email">
            <input type="submit" value="subscribe" class="btn">
        </form>
    
    </section>

</div>

<!-- newsletter section ends -->



 











<!-- footer section starts  -->

<footer class="footer">

    <section class="quick-links">

        <a href="home.php" class="logo"> <i class="fas fa-store"></i> Elektronics </a>
    
        <div class="links">
            <a href="home.php"> home </a>
            <a href="about.php"> about </a>
            <a href="contact.php"> contact </a>
            <a href="login.php"> login </a>
            <a href="register.php"> register </a>
           
        </div>
    
        <div class="share">
            <a href="https://www.facebook.com/andrei.telechi.5/" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="https://www.instagram.com/telechiandrei/" class="fab fa-instagram"></a>
            
        </div>
    
    </section>
    
    

</footer>

<!-- footer section ends -->




<!-- swiper js link      -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>